import axios from "axios";
import crypto from "crypto";

export async function handler(event) {
  const MY_SECRET_TOKEN = "c32a5f33c05b0edeeb1d120580c5328193946d25";

  const signature = event.headers["X-Hub-Signature-256"];
  const payload = JSON.stringify(event.body);

  console.log("payload", payload);

  if (!validateSignature(signature, payload, MY_SECRET_TOKEN)) {
    return {
      statusCode: 401,
      body: JSON.stringify({
        message: "Invalid signature ",
      }),
    };
  }

  console.log("the payload", payload);

  try {
    console.log("the request", event);
    const githubEvent = JSON.parse(event.body);

    if (githubEvent.action === "created") {
      const slackMessage = {
        channel: "C064348562K",
        text: `New star for the repository! 🌟 Total stars: ${githubEvent.repository.stargazers_count}`,
        blocks: [
          {
            type: "rich_text",
            elements: [
              {
                type: "rich_text_section",
                elements: [
                  {
                    type: "emoji",
                    name: "star",
                  },
                  {
                    type: "text",
                    text: "  Woohoo, we have a new star!  ",
                    style: {
                      bold: true,
                    },
                  },
                  {
                    type: "emoji",
                    name: "star",
                  },
                ],
              },
            ],
          },
          {
            type: "rich_text",
            elements: [
              {
                type: "rich_text_list",
                style: "bullet",
                elements: [
                  {
                    type: "rich_text_section",
                    elements: [
                      {
                        type: "text",
                        text: `repo:  ${githubEvent.repository.full_name}`,
                      },
                    ],
                  },
                  {
                    type: "rich_text_section",
                    elements: [
                      {
                        type: "text",
                        text: `user: ${githubEvent.sender.login}`,
                      },
                    ],
                  },
                ],
              },
            ],
          },
          {
            type: "rich_text",
            elements: [
              {
                type: "rich_text_section",
                elements: [
                  {
                    type: "text",
                    text: `Total stars: ${githubEvent.repository.stargazers_count}`,
                  },
                ],
              },
            ],
          },
        ],
      };

      // Await the axios call to ensure it completes before the function returns
      const response = await axios.post(
        "https://slack.com/api/chat.postMessage",
        slackMessage,
        {
          headers: {
            Authorization: `Bearer xoxb-3519495607122-6139269792183-dys7nnK5A53oCiqXfgFfNB4J`,
            "Content-Type": "application/json",
          },
        }
      );

      console.log("Message posted successfully!", response.data);
      return {
        statusCode: 200,
        body: JSON.stringify({
          message: "Event processed for repo: " + githubEvent.repository.name,
        }),
      };
    } else {
      return {
        statusCode: 200,
        body: JSON.stringify({ message: "No new star event" }),
      };
    }
  } catch (error) {
    console.log("Error making Slack call:", error.message);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "An error occurred: " + error.message }),
    };
  }
}

// Function to validate the signature
function validateSignature(signature, payload, secretToken) {
  const computedSignature =
    `sha256=` +
    crypto.createHmac("sha256", secretToken).update(payload).digest("hex");
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(computedSignature)
  );
}
